const express=require('express');

const bodyParser = require("body-parser")
const app=express();

app.set('view engine','ejs');




app.use(bodyParser.json())
app.use(express.static('public'))
app.use(bodyParser.urlencoded({
    extended:true
}))




console.log("Listening on PORT 9000");










const classrouter=require('./routers/class');

app.use('/',classrouter);
app.use('/',classrouter);
app.use('/',classrouter);
app.use('/',classrouter);
app.use('/',classrouter);
app.use('/:id',classrouter);
app.use('/:id/post',classrouter);
app.use('/',classrouter);
app.use('/',classrouter);
app.use('/',classrouter);

/*app.get('/hod',(req,res)=>{
    let device_list=[{'name':'abc'},{'name':'rak'}]
    res.render('hod',{'devices' : device_list})
})*/



app.listen(8001,()=>console.log('server started'));