exports.mydate= function()
{
    var d= new Date();
    return d.toString();
};