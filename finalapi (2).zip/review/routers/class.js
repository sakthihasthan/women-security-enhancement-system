const mongoose=require('mongoose');
const url='mongodb://localhost/sample';
const express=require('express');
const router=express.Router();
const assert=require('assert');
const crypto=require('crypto');
var dt=require('./date');


mongoose.connect(url,{
    useNewUrlParser: true,
    useUnifiedTopology: true
});

const con = mongoose.connection;

con.on('error',()=>console.log("Error in Connecting to Database"));
con.once('open',()=>console.log("Connected to Database"))

var staff__id="";

router.get("/",(req,res)=>{
    res.set({
        "Allow-access-Allow-Origin": '*'
    })
    res.render('index',{error:''})
});

router.post('/entry',async(req,res)=>{
    try{
    var usermail = req.body.user_id;
    var pass=req.body.paasword;
    if(usermail.match(/([a-z]@student.tce.edu)/)){
        const user = await con.collection('user').findOne({email:usermail})
        if(user.password === pass && user.fname===""){
            return res.redirect('stud_profile.html')
        }
        else if(user.password === pass){
            
            return res.redirect(user.id+'/stud_sol')
        }else{
            res.render('index',{error:'Wrong Matching!!!'})
        }
    
    }else if(usermail.match(/([a-z]@tce.edu)/)){
        return res.redirect('hod')
    }else if(usermail.match(/([a-z]@staff.tce.edu)/)){
        const users = await con.collection('staff').findOne({email:usermail})
        if(users.password === ""){
            return res.redirect('staff_profile.html')
        }
        else if(users.password === pass){
            staff__id=users.staff_id;
            return res.redirect('staffs/'+users.id)
        }
    }else{
        res.render('index',{error:'Wrong Matching!!!'})
        
    }
}catch (error) {
        
}
    
})



router.post("/register",async(req,res)=>{
    var username = req.body.uname;
    var mail = req.body.umail;
    var password = req.body.pass;
    var no = req.body.no;
    var conpassword = req.body.ppass;

    if(password === conpassword){
        var data = {
            "id":crypto.randomBytes(16).toString("hex"),
            "regno":"",
            "username": username,
            "email": mail,
            "Mobile_no":no,
            "fname":"",
            "lname":"",
            "program": "",
            "bio":"",
            "dob": "",
            "year":"",
            "address":"",
            "city":"",
            "zip":"",
            "password": password,
        }
        const user = await con.collection('user').findOne({username:username})
        if(user != null){
            console.log("Username already exists")
            res.render('index',{error:'Username already exists!!!'})
        }else{    
            con.collection('user').insertOne(data,(err,collection)=>{
                if(err){
                    throw err;
                }
                console.log("Record Inserted Successfully");
            });
            res.render('index',{error:'Registered Successfully...'})
        }
    }
    else{
        res.render('index',{error:'Wrong matching of password!!!'})
    }
})


router.post("/add_staffs",async(req,res)=>{
    var mail = req.body.mailid;
    var staffid=req.body.staffid;
        var data = {
            "id":crypto.randomBytes(16).toString("hex"),
            "email": mail,
            "staff_id":staffid,
            "password": "",
            "fname":"",
            "lname":"",
            "mobile":"",
            "position": "",
            "bio":"",
            "dob": "",
            "degree":"",
            "address":"",
            "city":"",
            "zip":"",
        }
        const user = await con.collection('staff').findOne({email:mail})
        if(user != null){
            console.log("Username already exists")
            res.send("Username already exists")
        }else{    
            con.collection('staff').insertOne(data,(err,collection)=>{
                if(err){
                    throw err;
                }
                console.log("Record Inserted Successfully");
            });
            con.collection('users').find({}).toArray(async function(err,prob){
                assert.equal(err,null);
                const ons= await con.collection('users').count({domain:'On Staff'})
        const ona= await con.collection('users').count({domain:'On Assignment'})
        const onc= await con.collection('users').count({domain:'On Credits'})
        const onat= await con.collection('users').count({domain:'On Attendance'})
                res.render('hod',{suc:'Staff has been added successfullyy....',problem : prob,ons:ons,ona:ona,onc:onc,onat:onat})
            })
        }

    
})


router.post("/staff_profile", async(req,res)=>{
    try {
        var fname = req.body.fname;
        var lname = req.body.lname;
        var email=req.body.email;
        var mobile=req.body.mobile;
        var bio=req.body.bio;
        var posi=req.body.position;
        var dob=req.body.dob;
        var degree=req.body.degree;
        var address=req.body.address;
        var city=req.body.city;
        var zip=req.body.zip;
        var password=req.body.pass;
        
        const user = await con.collection('staff').findOne({email:email})
        if(user.password === ""){
            console.log(user.password)
            var myquery = { email:email };
            var newvalues = { $set: {password: password, fname: fname, lname: lname, bio: bio, position: posi, dob: dob, degree:degree, address:address, city: city, zip: zip } };
            con.collection("staff").updateOne(myquery, newvalues, function(err, collection) {
                if (err) throw err;
                return res.redirect('staffs/'+user.id)

             });
        }
        else{
            res.send("Wrong matching")
        }
   
    } catch (error) {
        
    }
    

})


router.post("/stud_profile", async(req,res)=>{
    try {
        var fname = req.body.fname;
        var lname = req.body.lname;
        var email=req.body.email;
        var mobile=req.body.mobile;
        var bio=req.body.bio;
        var posi=req.body.position;
        var dob=req.body.dob;
        var degree=req.body.degree;
        var address=req.body.address;
        var city=req.body.city;
        var zip=req.body.zip;
        var reg=req.body.reg;
        var password=req.body.pass;
        
        const user = await con.collection('user').findOne({email:email})
        if(user.password === password){
            var myquery = { email:email };
            var newvalues = { $set: {password: password, fname: fname, lname: lname,regno:reg, mobile: mobile, bio: bio, program: posi, dob: dob, year:degree, address:address, city: city, zip: zip } };
            con.collection("user").updateOne(myquery, newvalues, function(err, collection) {
                if (err) throw err;
                return res.redirect(user.id+'/stud_sol')

             });
        }
        else{
            res.send("Wrong matching")
        }
   
    } catch (error) {
        
    }
    

})


router.get('/:id/stud_sol',(req,res)=>{

    con.collection('user').find({"id":req.params.id}).toArray(async function(err,opp){
        assert.equal(err,null);
        const nosolp=await con.collection('users').count({sol:''})
        const proo=await con.collection('users').count()
        const pro=(((proo-nosolp)/proo)*100);
        const nosol=((nosolp/proo)*100);
        var prof=[...opp]
        con.collection('users').find({"regno":opp[0].regno}).toArray(function(err,out){
            res.render('stud_sol',{'prof':prof,'solu' : out,nosol:nosol,pro:pro})
        })
    })

})

router.get('/complaint',(req,res)=>{
    res.render('stud',{success:''})
})


router.get('/cl',(req,res)=>{res.send('hii')});

router.get('/staffs/:id',async(req,res)=>{
    const user = await con.collection('staff').findOne({"id":req.params.id})
    con.collection('share').find({"staff_id":user.staff_id}).toArray(function(err,opp){
        assert.equal(err,null);
        con.collection('staff').find({"staff_id":user.staff_id}).toArray(function(err,out){
            
            /*var op=[]
            for(let i=0;i<opp.length;i++){
                op.push(opp[i].problem)
            }*/
            var pro=[...out]
            var op=out[0].email
            var idss=out[0].id;
            res.render('staffs',{'det':op,'sol' : opp,'pro':pro,'idss':idss})
        })
    
    })

    /*con.collection('share').aggregate([
        {
            $lookup:{
                from:'staff',
                localField:'staff_id',
                foreignField:'staff_id',
                as:'problems'
            }
        },{$replaceRoot:{
            newRoot:{
                $mergeObjects:[{
                    $arrayElemAt:["$problems",0]
                },"$$ROOT"]
            }
        }}
    ]).toArray(function(err,op){
        if(err){
            throw err;
        }
    for(let i=0;i<op.length;i++){
        if(op[i].staff_id==staff__id){
            console.log(op[i].problem)
            res.render('staffs',{'sol':op[i]})
        }
    }
    })*/
    

    
})



router.post("/post_hod",(req,res)=>{
    var srid = req.body.rid;
    var soll = req.body.ssol;
    var email = req.body.smail;
    var prob =req.body.prob;
    var sid=req.body.sid;
    var idss= req.body.idss;


    

    var myquery = { rid: srid, staff_id: sid, problem: prob};
            var newvalues = { $set: {sol: soll, Staff_mail: email} };
            con.collection("share").updateMany(myquery, newvalues, function(err, collection) {
                if (err) {throw err};

                console.log("Record Inserted Successfully");
});

    return res.redirect('staffs/'+idss)


});


router.get('/hod',async(req,res)=>{
    
    con.collection('users').find({}).toArray(async function(err,prob){
        assert.equal(err,null);
        const ons= await con.collection('users').count({domain:'On Staff'})
        const ona= await con.collection('users').count({domain:'On Assignment'})
        const onc= await con.collection('users').count({domain:'On Credits'})
        const onat= await con.collection('users').count({domain:'On Attendance'})

        res.render('hod',{suc:'',problem : prob,ons:ons,ona:ona,onc:onc,onat:onat})
    })

    
})


router.get('/:id',(req,res)=>{

    console.log(req.params.id);
    con.collection('users').find({"id":req.params.id}).toArray(function(err,prob){
        assert.equal(err,null);
        //con.collection('users').findOne({"id":req.params.id}).toArray((err,result)=>{
        //con.collection('users').countDocuments({"regno":result.regno},(err,count)=>{
            res.render('stuser',{'ans' : prob})
        //})
    })
        
    })

    
//})

router.post('/:id/post',(req,res)=>{

    console.log(req.params.id);
    con.collection('users').find({"id":req.params.id}).toArray(function(err,prob){
        assert.equal(err,null);
        con.collection('staff').find({}).toArray(function(err,result){
                con.collection('share').find({"problem":prob[0].problem,"rid":prob[0].regno}).toArray((err,sts)=>{
                    var ids=result.id
                res.render('post',{'ids':ids,'sol' : prob,'st':result,'sts':sts})
            })
        })
        })
    
        })
        
router.post("/share",async(req,res)=>{
    try {
    var prob=req.body.prob;
    var astaff = req.body.allstaff;
    var staff = req.body.staff;
    var rid=req.body.rid;
    var ids=req.body.ids;
    var yr=req.body.yr;
    var slot=req.body.slot;

    
    var is_array=function(ip){
        if(toString.call(ip)=="[object Array]"){return true;}
        else{return false;}
    }
    if(astaff=="on"){
        con.collection('staff').find({}).toArray(async function(err,probl){
            assert.equal(err,null);
            for(let i=0;i<probl.length;i++){
                var data={
                    "staff_id":probl[i].staff_id,
                    "problem":prob,
                    "rid":rid,
                    "year":yr,
                    "slot":slot,
                    "Staff_mail":"",
                    "sol":"",
                    "date":dt.mydate(),
                }
                
                
                con.collection('share').insertOne(data,(err,collection)=>{
                    if(err){
                        throw err;
                    }
                    console.log("Record Inserted Successfully");
                    
                });
                
            }return res.redirect('hod')
        })

    }
    if(staff !="No"){
    if(is_array(staff)==false){
        var data={
            "staff_id":staff,
            "problem":prob,
            "rid":rid,
            "year":yr,
            "slot":slot,
            "Staff_mail":"",
            "sol":"",
            "date":dt.mydate(),
        }
        
            con.collection('share').insertOne(data,(err,collection)=>{
                if(err){
                    throw err;
                }
                console.log("Record Inserted Successfully");
            });
        
        
        return res.redirect('hod')
    }else{
        for(let i=0;i<staff.length;i++){
            var data={
                "staff_id":staff[i],
                "problem":prob,
                "rid":rid,
                "year":yr,
                "slot":slot,
                "Staff_mail":"",
                "sol":"",
                "date":dt.mydate(),
            }
            
            con.collection('share').insertOne(data,(err,collection)=>{
                if(err){
                    throw err;
                }
                console.log("Record Inserted Successfully")
                
            });
        }return res.redirect('hod')
    }
    }
} catch (error) {
        
}

});  


router.post("/sol_post",(req,res)=>{
    var pprob = req.body.probs;
    var rreg = req.body.reg;
    var eemail = req.body.em;
    var ssol =req.body.sol;

    
    
    var myquery = { email:eemail,regno:rreg,problem:pprob };
            var newvalues = { $set: {sol:ssol} };
            con.collection("users").updateOne(myquery, newvalues, function(err, collection) {
                if (err) {throw err};
                
                console.log("Record Inserted Successfully");

    
    return res.redirect('hod')
});

});


router.post("/submit",(req,res)=>{
    var fname = req.body.first_name;
    var lname = req.body.last_name;
    var email = req.body.email;
    var phone = req.body.phone;
    var address = req.body.address;
    var yr = req.body.year;
    var slot = req.body.slot;
    var state = req.body.state;
    var domain = req.body.website;
    //const d=new Data();
    var data = {
        "id":crypto.randomBytes(16).toString("hex"),
        "fname": fname,
        "lname": lname,
        "email" : email,
        "phone": phone,
        "regno": address,
        "year":yr,
        "slot":slot,
        "domain": state,
        "problem": domain,
        "sol":"",
        "Date":dt.mydate(),
    }

    con.collection('users').insertOne(data,(err,collection)=>{
        if(err){
            throw err;
        }
        console.log("Record Inserted Successfully");
        return res.render('stud',{success:'Complaint posted Successfully......'})
    });

    


});





module.exports=router;